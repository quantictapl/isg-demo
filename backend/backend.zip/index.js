const clientLoginPath = "/clientlogin";
const loginPath = "/login";
const registerPath = "/register";
const verifyPath = "/verify";
const registerService = require("./services/register");
const loginService = require("./services/Login");
const verifyService = require("./services/verify");
const util = require("./utils/utils");
const cors = require("cors")({ origin: true }); // Add this line

exports.handler = async (event, context, callback) => {
  console.log("Request Event:", event);

  let response;

  switch (true) {
    case event.httpMethod === "GET" && event.path === clientLoginPath:
      console.log("GET request received for client login");
      response = util.buildResponse(200);
      break;
    case event.httpMethod === "POST" && event.path === registerPath:
      console.log("POST request received for register");
      const registerBody = JSON.parse(event.body);
      response = await registerService.register(registerBody);
      break;
    case event.httpMethod === "POST" && event.path === loginPath:
      console.log("POST request received for login");
      const loginBody = JSON.parse(event.body);
      response = await loginService.login(loginBody);
      break;
    case event.httpMethod === "POST" && event.path === verifyPath:
      console.log("POST request received for verify");
      const verifyBody = JSON.parse(event.body);
      response = verifyService.verify(verifyBody);
      break;
    case event.httpMethod === "OPTIONS":
      response = util.buildResponse(200, "Success");
      break;
    default:
      console.log("Invalid request received");
      response = util.buildCORSResponse(404, "404 Not Found");
  }

  console.log("Response:", response);

  // Add the following block to enable CORS headers
  cors(event, context, () => {
    callback(null, response);
  });
};